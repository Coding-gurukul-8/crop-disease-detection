// Application layout scaffold.
