// Card component scaffold.
