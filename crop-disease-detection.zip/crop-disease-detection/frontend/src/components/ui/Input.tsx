// Input component scaffold.
