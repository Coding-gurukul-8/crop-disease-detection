// Button component scaffold.
