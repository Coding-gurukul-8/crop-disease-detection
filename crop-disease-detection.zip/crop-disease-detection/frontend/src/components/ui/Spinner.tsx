// Spinner component scaffold.
