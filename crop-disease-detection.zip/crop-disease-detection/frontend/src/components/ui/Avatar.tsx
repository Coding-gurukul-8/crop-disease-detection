// Avatar component scaffold.
