// Dashboard statistics card scaffold.
