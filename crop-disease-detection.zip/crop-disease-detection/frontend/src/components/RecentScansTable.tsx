// Recent scans table scaffold.
