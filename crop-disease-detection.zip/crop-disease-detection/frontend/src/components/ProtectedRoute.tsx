// Protected route scaffold.
