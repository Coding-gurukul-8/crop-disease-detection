// Authentication state store scaffold.
