// Frontend API client scaffold.
