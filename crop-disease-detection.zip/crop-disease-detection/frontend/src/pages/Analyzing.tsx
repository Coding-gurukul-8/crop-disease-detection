// Analysis progress page scaffold.
