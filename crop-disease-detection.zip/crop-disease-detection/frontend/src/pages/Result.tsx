// Prediction result page scaffold.
