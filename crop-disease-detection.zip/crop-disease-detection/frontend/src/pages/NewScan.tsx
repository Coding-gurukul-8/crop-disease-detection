// New scan page scaffold.
