// Signup page scaffold.
