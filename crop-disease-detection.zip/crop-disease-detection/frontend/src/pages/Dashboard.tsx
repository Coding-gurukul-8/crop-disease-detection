// Dashboard page scaffold.
