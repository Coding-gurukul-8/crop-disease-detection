// Scan history page scaffold.
