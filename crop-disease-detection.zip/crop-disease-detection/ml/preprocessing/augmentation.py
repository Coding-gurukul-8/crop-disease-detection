"""Image augmentation utilities."""
