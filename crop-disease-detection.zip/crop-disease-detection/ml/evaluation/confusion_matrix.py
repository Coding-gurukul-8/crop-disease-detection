"""Confusion-matrix generation utilities."""
