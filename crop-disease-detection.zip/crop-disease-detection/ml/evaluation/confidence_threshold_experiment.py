"""Confidence-threshold evaluation experiment."""
