"""Image prediction routes."""
