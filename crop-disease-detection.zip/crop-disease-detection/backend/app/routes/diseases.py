"""Disease catalog routes."""
