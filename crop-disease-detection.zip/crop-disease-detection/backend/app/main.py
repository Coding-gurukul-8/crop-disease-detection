"""FastAPI application entry point."""
