"""Disease database model."""
