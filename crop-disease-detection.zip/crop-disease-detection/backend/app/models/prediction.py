"""Prediction database model."""
