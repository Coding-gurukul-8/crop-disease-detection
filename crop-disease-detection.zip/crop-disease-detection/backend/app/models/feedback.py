"""Feedback database model."""
