"""Prediction image preprocessing service."""
