"""Shared FastAPI dependencies."""
