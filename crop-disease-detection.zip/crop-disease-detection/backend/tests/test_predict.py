"""Prediction route tests."""
