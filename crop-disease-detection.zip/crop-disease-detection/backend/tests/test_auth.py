"""Authentication route tests."""
